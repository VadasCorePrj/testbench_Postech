#include <iostream>
#include <testbench.hpp>
#include <lga.hpp>
#include <precisetimer.hpp>

#include "opencv2/opencv.hpp"

#define DMSGN(x) do { std::cout << x << std::endl; } while(0)
#define DMSG(x) do { std::cout << x << " "; } while(0)


using namespace std;
using namespace testbench;

using namespace cv;
void fill_tensor_512(Mat& src);
/**
 * create module parameters in LGA area.
 */
TESTBENCH_MODULE(t_testbenchParam, s32Opencv_512);

t_tbspec SPEC(s32Opencv_512) = {
	.tspec = {
		.iter = 100,
		.unroll = 30,
		.retry = 3,
		.elapsed = vector<double>(0,0),
		.opcycle = 0,
	},
	.fspec = {
		.type = FILTER_DEFAULT,		// the default filter
		.priv = 10,					// low threshold percent
	}
};

double MAINFUNC(s32Opencv_512)(tbHandler* pHandler)
{
	int len = pHandler->getIter();
	double durations[len];
	int M = 512;
	int N = 512;
	int K = 512;
	
	
	Mat src0 = Mat (K, M, CV_32FC1);
	Mat src1 = Mat (N, K, CV_32FC1);
	Mat dst  = Mat (N, M, CV_32FC1);

	fill_tensor_512(src0);
	fill_tensor_512(src1);
	for (auto i=0;i<len; ++i){
		precisetimer::kick();
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;//10

		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;//20

		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;
		dst = src1*src0;//30

		precisetimer::stop();

		durations[i] = precisetimer::duration<double,std::nano>();
		//durations[i] = precisetimer::duration<double,std::seconds>();
	}
	return pHandler->analyze(len, durations);

}

void SETUPFUNC(s32Opencv_512)()
{
// create testbench handler using timespec.
	tbHandler* tb_int32Handler = new tbHandler(&SPEC(s32Opencv_512), toString(s32Opencv_512));

	tb_int32Handler->gplot = PARAM(s32Opencv_512).flagGnuPlot;

	double theBest = -1;				// initial value is -1
	int retryCount = SPEC(s32Opencv_512).tspec.retry;
	cout << "s32 Opencv  512 " << endl;
	while (retryCount > 0) {
		// execute main function of this module
		double theResult = MAINFUNC(s32Opencv_512)(tb_int32Handler);

		// update retry count depending on the result of MAINFUNC
		if (theBest < 0) {
			theBest = theResult;		// this is the first time
		} else {
			if (theResult < theBest) {	
				// if the result of this trial is better - smaller because it is time - than before.
				theBest = theResult;		
				retryCount = SPEC(s32Opencv_512).tspec.retry;	// reload the retryCount
			} else {
				retryCount--;
			}
		}
	}
	cout << toString(s32Opencv)<< ": " << theBest << " nsec." << endl;

	delete tb_int32Handler;
}
void fill_tensor_512(Mat& src)
{
	float low = -1.0f;
	float high = 1.0f;

	randu(src, Scalar(low), Scalar(high));
}

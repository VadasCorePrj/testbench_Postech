/*
 * imx6Neon.cpp
 *
 *  Created on: April 4, 2019
 *      Author: Woong
 */

#include <iostream>
#include <testbench.hpp>
#include <lga.hpp>
#include <precisetimer.hpp>

#include "arm_compute/core/Types.h"
#include "arm_compute/runtime/NEON/NEFunctions.h"
#include "arm_compute/runtime/NEON/NEScheduler.h"
#include "utils/Utils.h"
#include <cstdlib>

using namespace std;
using namespace testbench;

using namespace arm_compute;
using namespace utils;

/**
 * create module parameters in LGA area.
 */
TESTBENCH_MODULE(t_testbenchParam, s32neon_256);
//class tb_NeonHandler;
/**
 * define time spec used in this module.
 */
t_tbspec SPEC(s32neon_256) = {
	.tspec = {
		.iter = 100,
		.unroll = 30,
		.retry = 3,
		.elapsed = vector<double>(0,0),
		.opcycle = 0,
	},
	.fspec = {
		.type = FILTER_DEFAULT,		// the default filter
		.priv = 10,					// low threshold percent
	}
};

class NESGEMMExample : public Example
{
public:
    bool do_setup() //override
    {
        NPYLoader npy0, npy1, npy2;
        alpha = 1.0f;
        beta  = 0.0f;
        std::ifstream stream;

        size_t M = 256;
        size_t K = 256;
        size_t N = 256;

        src0.allocator()->init(TensorInfo(TensorShape(K, M), 1, DataType::F32));
        src1.allocator()->init(TensorInfo(TensorShape(N, K), 1, DataType::F32));

        init_sgemm_output(dst, src0, src1, DataType::F32);

        // Configure function
        sgemm.configure(&src0, &src1, nullptr, &dst, alpha, beta);

        // Allocate all the images
        src0.allocator()->allocate();
        src1.allocator()->allocate();
        dst.allocator()->allocate();

        // Fill the input images with either the data provided or random data
        fill_random_tensor(src0, -1.f, 1.f);
        fill_random_tensor(src1, -1.f, 1.f);

        // Dummy run for CLTuner
        sgemm.run();


        return true;
    }
    void do_run() //override
    {

        // Execute the function
        sgemm.run();

    }
    void do_teardown() //override
    {
        if(!output_filename.empty()) /* Save to .npy file */
        {
            save_to_npy(dst, output_filename, is_fortran);
        }
    }

private:
    Tensor      src0{}, src1{}, src2{}, dst{};
    NEGEMM      sgemm{};
    float       alpha{}, beta{};
    bool        is_fortran{};
    std::string output_filename{};
};

/**
 * MAIN function of this module.
 * @param pTestbenchMod: testbench handler class containing iteration information.
 */
double MAINFUNC(s32neon_256)(tbHandler* pHandler)
{

	int len = pHandler->getIter();
	double durations[len];

		
	NESGEMMExample* tb_NESGEMMExample = new NESGEMMExample;
	tb_NESGEMMExample->do_setup();

	for (auto i = 0; i < len; i++){
		
		

		precisetimer::kick();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();//10

		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();//20

		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();
		tb_NESGEMMExample->do_run();//30


		precisetimer::stop();

		durations[i] = precisetimer::duration<double,std::nano>();
		
	}
	delete tb_NESGEMMExample;
	return pHandler->analyze(len, durations);

}

/**
 * SETUP function of this module.
 */
void SETUPFUNC(s32neon_256)()
{
	// create testbench handler using timespec.
	tbHandler* tb_int32Handler = new tbHandler(&SPEC(s32neon_256), toString(s32neon_256));

	tb_int32Handler->gplot = PARAM(s32neon_256).flagGnuPlot;

	double theBest = -1;				// initial value is -1
	int retryCount = SPEC(s32neon_256).tspec.retry;
	cout << "s32 Neon 256 " << endl;
	while (retryCount > 0) {
		// execute main function of this module
		double theResult = MAINFUNC(s32neon_256)(tb_int32Handler);

		// update retry count depending on the result of MAINFUNC
		if (theBest < 0) {
			theBest = theResult;		// this is the first time
		} else {
			if (theResult < theBest) {	
				// if the result of this trial is better - smaller because it is time - than before.
				theBest = theResult;		
				retryCount = SPEC(s32neon_256).tspec.retry;	// reload the retryCount
			} else {
				retryCount--;
			}
		}
	}
	cout << toString(s32neon_256)<< ": " << theBest << " nsec." << endl;

	delete tb_int32Handler;
}


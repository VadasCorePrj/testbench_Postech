/*
 * imx6OpenBALS.cpp
 *
 *  Created on: April 4, 2019
 *      Author: Woong
 */

#include <iostream>
#include <testbench.hpp>
#include <lga.hpp>
#include <precisetimer.hpp>
#include <cblas.h>

using namespace std;
using namespace testbench;

/**
 * create module parameters in LGA area.
 */
TESTBENCH_MODULE(t_testbenchParam, s32Openblas_512);

/**
 * define time spec used in this module.
 */

t_tbspec SPEC(s32Openblas_512) = {
	.tspec = {
		.iter = 100,
		.unroll = 30,
		.retry = 3,
		.elapsed = vector<double>(0,0),
		.opcycle = 0,
	},
	.fspec = {
		.type = FILTER_DEFAULT,		// the default filter
		.priv = 10,					// low threshold percent
	}
};

/**
 * MAIN function of this module.
 * @param pTestbenchMod: testbench handler class containing iteration information.
 */
double MAINFUNC(s32Openblas_512)(tbHandler* pHandler)
{

	// iteration information
	int len = pHandler->getIter();
	// the code in loop should be matched with unroll.
//	int unroll = pHandler->getUnroll();

	// time slices to store duration
	double durations[len];

	// Random Matrix Generation
	const int M = 512;
	const int K = 512;
	const int N = 512;
	
	int sizeA = M*K;
	int sizeB = K*N;
	int sizeC = M*N;
	float R = 1.0;

	
	float *numPtrMatA = (float*)malloc(sizeof(float) * sizeA );
	float *numPtrMatB = (float*)malloc(sizeof(float) * sizeB );
	float *numPtrMatC = (float*)malloc(sizeof(float) * sizeC );
	for (int i = 0; i < sizeA; i++){
		numPtrMatA[i] = R*(float)rand()/(float)(RAND_MAX)*R;
	}
	for (int i = 0; i < sizeB; i++){
		numPtrMatB[i] = R*(float)rand()/(float)(RAND_MAX);
	}
	for (int i = 0; i < sizeC; i++){
		numPtrMatC[i] = 1.0;
	}
	
	for (auto i = 0; i < len; i++){


		//Matrix multiplication
		precisetimer::kick();

		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N); //10

		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N); //20
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N);
		cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,M,N,K,1.0,numPtrMatA, K, numPtrMatB, N,0.0,numPtrMatC,N); //30

		

		precisetimer::stop();
	
		durations[i] = precisetimer::duration<double,std::nano>();
	}

	return pHandler->analyze(len, durations);

}

/**
 * SETUP function of this module.
 */
void SETUPFUNC(s32Openblas_512)()
{

	tbHandler* tb_int32Handler = new tbHandler(&SPEC(s32Openblas_512), toString(s32Openblas_512));

	tb_int32Handler->gplot = PARAM(s32Openblas_512).flagGnuPlot;

	double theBest = -1;				// initial value is -1
	int retryCount = SPEC(s32Openblas_512).tspec.retry;
	cout << "s32 OpenBLAS 512 " << endl;
	while (retryCount > 0) {
		// execute main function of this module
		double theResult = MAINFUNC(s32Openblas_512)(tb_int32Handler);

		// update retry count depending on the result of MAINFUNC
		if (theBest < 0) {
			theBest = theResult;		// this is the first time
		} else {
			if (theResult < theBest) {	
				// if the result of this trial is better - smaller because it is time - than before.
				theBest = theResult;		
				retryCount = SPEC(s32Openblas_512).tspec.retry;	// reload the retryCount
			} else {
				retryCount--;
			}
		}
	}
	cout << toString(s32Openblas_512)<< ": " << theBest << " nsec." << endl;

	delete tb_int32Handler;
}

